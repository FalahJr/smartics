
					<div class="col-lg-12 grid-margin stretch-card alamraya-no-padding">
				      	<div class="card">
					        <div class="card-body">
					          <h4 class="card-title">Payroll Tunjangan</h4>
					          	<div class="row">

									<div class="col-md-12 col-sm-12 col-xs-12 alamraya-btn-add-row" align="right">
										<a class="btn btn-warning " href="{{url('hrd/payroll/setting_tunjangan')}}"><i class="fa fa-cog"></i>&nbsp;&nbsp;Setting Tunjangan Pegawai</a>
										<button class="btn btn-info" data-toggle="modal" data-target="#tambahtunjangan"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Data</button>
									</div>
									<div class="table-responsive">
										<table id="tbl_tunjangan" class="table table-hover" cellspacing="0" style="width:100%">
										  <thead class="bg-gradient-info">
										    <tr>
										      <th>Nama</th>
										      <th>Periode</th>
										      <th>Nilai</th>
										      <th>Aksi</th>
										    </tr>
										  </thead>
										  <tbody class="center">
										    
										  </tbody>
										</table>
									</div>

					        	</div>
					      	</div>
				    	</div>
					</div>
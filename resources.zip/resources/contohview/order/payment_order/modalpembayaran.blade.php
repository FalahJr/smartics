<!-- Modal -->
<div id="pembayaran" class="modal fade" role="dialog">
  <div class="modal-dialog modal-md">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header bg-gradient-info">
        <h4 class="modal-title">Detail Pembayaran</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <center>
        <div class="row">
          <div class="table-responsive" style="margin-bottom: 15px;">
            <table class="table table-hover" cellspacing="0" id="tablepembayaran">
						  <thead class="bg-gradient-info">
                <tr>
                  <th id="noqo"></th>
                  <th id="2clm"></th>
                  <th id="3clm"></th>
                </tr>
						  </thead>
						  <tbody>

						  </tbody>
						</table>
          </div>



         </div> <!-- End div row -->
         <div class="row">
           <div class="col-md-2">
             <label for="">Total : </label>
           </div>
           <div class="col-md-5" id="total">

           </div>
         </div>
       </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

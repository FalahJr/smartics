
<footer>
    <div class="container pt-3 pt-md-5">
      <div class="row col-12">
        <div class="col-12 col-md-3 mt-4 mt-md-0">
          <img src="assets/logo.png" width="120px" alt="" />
          <p>
            Lorem Ipsun Dolorsit amet Lorem Ipsun Dolorsit amet Lorem Ipsun
            Dolorsit amet Lorem Ipsun
          </p>
        </div>
        <div class="col-12 col-md-3 mt-4 mt-md-0">
          <h3>Sosial Media</h3>
          <ul>
            <li>
              <a href="#" class="text-dark">Instagram</a>
            </li>
            <li>
              <a href="#" class="text-dark">Twiter</a>
            </li>
            <li>
              <a href="#" class="text-dark">LinkedIn</a>
            </li>
            <li>
              <a href="#" class="text-dark">Youtube</a>
            </li>
          </ul>
        </div>
        <div class="col-12 col-md-3 mt-4 mt-md-0">
          <h3>Contact Us</h3>
          <ul>
            <li>(031) 81230912</li>
            <li>smartics@gmail.com</li>
          </ul>
        </div>
        <div class="col-12 col-md-3 mt-4 mt-md-0">
          <h3>Alamat</h3>
          <p>
            Jl Kenari No 57, Kec Jambangan, Kota Surabaya, Jawa Timur 60234
          </p>
        </div>
      </div>
    </div>
  </footer>

  <div class="row justify-content-center align-self-center pt-3 copyright">
    <p>Copyright 2023 By Smartics | All Rights Reserved.</p>
  </div>